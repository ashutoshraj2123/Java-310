 

// write a program to find factorial of number?



 class ew_me{

    public static void main(String[] args) {
        System.out.println("null");
    }
 }