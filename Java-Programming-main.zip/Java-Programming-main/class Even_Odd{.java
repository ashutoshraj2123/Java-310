class Even_Odd{

    public static void main(String[] args) {
        int arr[];
         arr= new int[10];
         arr
    }
}