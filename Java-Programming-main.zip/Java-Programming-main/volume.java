
class Volume{
// dot operator are called member acces operator 
int hi; int weight; static int h=12;


}
class  main{
    public static void main(String[] args) {
        Volume v= new Volume();
         v.hi;
        v.weight=30;
        // Volume.h=300;
     
             System.out.print(Volume.h);
        
    }
}

// functions 




