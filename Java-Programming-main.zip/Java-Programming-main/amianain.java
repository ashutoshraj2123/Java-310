    class mai2{
        public static void main(String[] args) {
            int first=1,di=4;

            int arr[];
             arr= new arr[20];
             for(int i=0;i<20;i++){
                arr[first]+=arr[di];
             }
             for(int j=0;j<20;j++){
                System.out.print(j[i]+" ");
             }
        }
    }