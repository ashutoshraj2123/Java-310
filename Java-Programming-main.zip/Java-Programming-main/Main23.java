public interface Main23 {
    public static void main(String[] args) {
        
    }
}
