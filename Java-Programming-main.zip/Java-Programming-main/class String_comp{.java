class String_comp{


    public static void main(String[] args) {
        String s1="I am Afzal Raza";
        String s2="I am Shesh Kumar";
int count1=0;
int count2=0;
        for(int i=0;i<s1.length();i++){
count1++;
        }
        for(int j=0;j<s2.length();j++){
            count2++;
        }

        if(count1>count2){
            
        }

    }
}