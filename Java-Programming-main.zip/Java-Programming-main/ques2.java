import java.util.Scanner;
public class ques2 {
    public static void main(String[] args) {
        


        try{
            int base,perpen,hypo;
             
        }



    }
}
