import java.util.Scanner;


class employee{
int emp_id;
 char rank;


 void get_details(){

    emp_id=
 }


void print_detials(){
    

    }}

class main{

    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        employee e= new employee();


    }
}