import java.util.Scanner;
public class qurestion {
    public static void main(String[] args) {
        


        try{
            int base,perpen,hypo;
             
        }



    }
}
