class new_class
{
     public static void main(String[] args) {
        
     }
}