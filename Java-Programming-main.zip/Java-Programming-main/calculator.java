 //WAP to create a calculator in which the case labels will be in string
 
 class calc{


    public static void main(string[] args) {
                        
                


    }
 } 

 